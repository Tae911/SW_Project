package com.sw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class hoteljpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
